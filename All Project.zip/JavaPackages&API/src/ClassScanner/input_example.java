/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassScanner;
import java.util.Scanner;
/**
 *
 * @author dimas_06
 */
public class input_example {
    public static void main(String[] args) {
        Scanner input = new Scanner (System.in);//Membuat Objek dari c:
        Long NIM;
        String Nama;
        String Alamat;
        String Jurusan;
        int Angkatan;
        String JenisKelamin;//Variabel String, Untuk Menyimpan Input dari Use: 
        
        System.out.print("Tulis Bioadata          :");
        
        System.out.println("      Nama            :");
        Nama = input.nextLine();
        
        System.out.println("Alamat                :");
        Alamat = input.nextLine();
        
        System.out.println("Jurusan               :"); 
        Jurusan = input.nextLine();
    
        System.out.println("JenisKelamin          :"); 
        JenisKelamin = input.nextLine();
        
        System.out.println("NIM                   :");
        NIM = input.nextLong();   
        
        System.out.println("Angkatan              :");
        Angkatan = input.nextInt();//Mendapatkan Input dari User
        
        System.out.println("NIM                   :"+NIM);
        System.out.println("Nama                  :"+Nama);
        System.out.println("Alamat                :"+Alamat);
        System.out.println("Jurusan               :"+Jurusan);
        System.out.println("Angkatan              :"+Angkatan);
        System.out.println("JenisKelamin          :"+JenisKelamin);
        System.out.println("HALO BRO!!!!");//Mencetak Output
    }
}
