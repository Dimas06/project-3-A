/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Classes;

/**
 *
 * @author dimas_06
 */
abstract class PersonAbstract {
   public String fname = "Dimas";
   public String lname = "Fadhilah";
   public String email = "Dimas.ehm06@gmail.com";
   public int age = 19;
   public abstract void study();
}
   class Student extends PersonAbstract {
       public int graduationYear = 2019;
       public void study(){
           System.out.println("Studying all day long");
       }
   }

