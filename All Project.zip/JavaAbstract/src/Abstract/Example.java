/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Abstract;

/**
 *
 * @author dimas_06
 */
// Abstract class
abstract class Manusia {
  // Abstract method (does not have a body)
  public abstract void ManusiaSound();
  // Regular method
  public void sleep() {
    System.out.println("khkhkhkh");
  }
}

// Subclass (inherit from Animal)
class Cowok extends Manusia {
  public void ManusiaSound() {
    // The body of animalSound() is provided here
    System.out.println("The cowok says: wee wee");
  }
}

class MyMainClass {
  public static void main(String[] args) {
    Cowok myCowok = new Cowok(); // Create a Pig object
    myCowok.ManusiaSound();
    myCowok.sleep();
  }
}
