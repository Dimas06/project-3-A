/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package attributes;

/**
 *
 * @author dimas_06
 */
public class MyClassPrivate {
    private String fname = "Dimas";
  private String lname = "Fadhilah";
  private String email = "Dimas.ehm06@gmail.com";
  private int age = 24;
  
public static void main(String[] args) {
    Person myObj = new Person();
    System.out.println("Name: " + myObj.fname + " " + myObj.lname);
    System.out.println("Email: " + myObj.email);
    System.out.println("Age: " + myObj.age);
  }
}
