/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package attributes;

/**
 *
 * @author dimas_06
 */
public class Person {
    public String fname = "Dimas";
    public String lname = "Fadhilah";
    public String email = "Dimas.ehm06@gmail.com";
    public int age = 19;
}
